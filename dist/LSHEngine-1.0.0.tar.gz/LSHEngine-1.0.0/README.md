# LSHEngine 
<h3>All in One for Locality-Sensitive Hashing</h3>
<br>
This repo aims to implement an engine for Locality-Sensitive Hashing (LSH). Modules should be able to be attached to this engine in order to create specific recommendations as output from the Engine.
